@extends('public.layouts.master')

@section('seo')
@endsection

@section('title')
@endsection


@section('content')
	
@endsection


@section('footer')
@endsection
