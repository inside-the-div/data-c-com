@extends('public.layouts.master')

@section('seo')
@endsection

@section('title')
Contact Us | {{Session::get('title')}}
@endsection


@section('content')
	<section>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="card mt-2 p-5 text-justify">
						<h1 class="text-center m-0">Contact Us</h1>
						<hr class="my-2 ">



						<div class="row my-4">
							<div class="col-12 col-lg-7">
								<form action="">
									
									<div class="row">
										<div class="col-12">
											<label for="name"><b>Name:</b></label>
											<input maxlength="200" type="text" class="form-control mb-2" id="name" placeholder="Your Full Name">
										</div>
									</div>
									<div class="row mb-2">
										<div class="col-12 col-lg-8">
											<label for="name"><b>Email:</b></label>
											<input maxlength="100" type="text" class="form-control" id="name" placeholder="Your Full Name">
										</div>
										<div class="col-12 col-lg-4">
											<label for="name"><b>Phone:</b></label>
											<input maxlength="15" type="text" class="form-control" id="name" placeholder="Your Full Name">
										</div>
									</div>


									<div class="row mb-2">
										<div class="col-12">
											<label for="subject"><b>Subject*</b></label>
											<select name="subject" id="subject" class="form-control ">
												<option value=""></option>
												<option value="i need products">i need products</option>
												<option value="Other">Other</option>
											</select>
										</div>
									</div>

									<div class="row mb-2">
										<div class="col-12">
											<label for="message"><b>Message*</b></label>
											<textarea maxlength="500" name="" id="message" cols="30" rows="3"class="form-control" placeholder="Your Message"></textarea>
										</div>
									</div>

									<input class="btn_1 full-width mt-3" type="submit" value="Submit">


								</form>
							</div>

							<div class="col-12 col-lg-5">
								
									<h2 style="font-size: 20px;" class="text-center">DoDo Online Shop</h2>
									<hr class="my-2">

									<address>
										<p class="mb-2"><b>Address: </b> Lorem ipsum dolor sit amet, consectetur adipisicing.</p>
										<p class="mb-2"><b>Phone: </b> {{Session::get('phone')}}</p>
										<p class="mb-2"><b>Email: </b> {{Session::get('email')}}</p>
										<p class="m-0"><b>Whats App: </b> {{Session::get('phone')}}</p>
									</address>

									
								
							</div>
						</div>



						<div>
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3652.034741497928!2d90.37562621544389!3d23.74614049485485!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b397617379%3A0x65238a1ebd4d4222!2sDhanmondi%208%20No%20Bridge%2C%20Dhaka%201205!5e0!3m2!1sen!2sbd!4v1596470079016!5m2!1sen!2sbd" width="100%" height="550" frameborder="0" style="border:2px solid #004dda; border-radius: 20px;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
@endsection


@section('footer')
@endsection