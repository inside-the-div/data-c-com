@extends('customer.layouts.master')



@section('title')
<title>Single New Order</title>
@endsection


@section('content')
	
	<div class="row">

		<div class="col-12 col-lg-6 mb-3">
			<div class="card p-3">
				<h2 class="font-20 font-pt">Admin Note</h2>
				<hr>
				@if($order->admin_note == '')
					<p class="text-danger">Admin not comment yet.</p>
				@else
					<p>{{$order->admin_note}}</p>
				@endif
				
			</div>
		</div>


		<div class="col-12 col-lg-6 mb-3">
			<div class="card p-3">
				<h2 class="font-20 font-pt">Order Details</h2>
				<hr>
				
				<div class="row">
					<div class="col-12 col-lg-6">
						<ul class="group-list">
							<li class="font-pt font-16 mb-1"><b>Order Code: </b>{{$order->order_code}}</li>
							<li class="font-pt font-16 mb-1"><b>Total Products: </b>{{$order->total_product}}</li>
							<li class="font-pt font-16 mb-1"><b>Total Quantity: </b>{{$order->total_quantity}}</li>
							<li class="font-pt font-16 mb-1"><b class="text-info">Shipping Cost: </b>{{$shipping->shipping_cost}} Tk</li>
							<li class="font-pt font-16 mb-1"><b>Total Cost (without shipping): </b>{{$order->sub_total_cost}} Tk</li>
							<li class="font-pt font-16 mb-1"><b>Total Cost: </b>{{$order->total_cost}} Tk</li>
							<li class="font-pt font-16"><b>Total Payment: </b>{{$order->payment_cost}} Tk</li>

						</ul>
					</div>

					<div class="col-12 col-lg-6">
						<ul class="group-list">
							<li class="font-pt font-16 mb-1"><b class="text-info">Payment Status: </b>{{$order->payment}}</li>
							<li class="font-pt font-16 mb-1 "><b class="text-info">Order Status: </b>{{$order->status}}</li>
							<li class="font-pt font-16 mb-1 "><b class="text-info">Order Process: </b>{{$order->process}} %</li>
							<li class="font-pt font-16 "><b>Emergency phone: </b>{{$order->emergency_phone}} </li>
						</ul>
					</div>


				</div>
			
			</div>
		</div>

		<div class="col-12 col-lg-6 mb-3">
			<div class="card p-3">
				<h2 class="font-20 font-pt">Billing Details</h2>
				<hr>

				<ul class="group-list">
					<li class="font-pt font-16 mb-1"><b>Name: </b>{{$billing->first_name}} {{$billing->last_name}}</li>
					<li class="font-pt font-16 mb-1"><b>Phone: </b>{{$billing->phone}}</li>
					<li class="font-pt font-16 mb-1"><b>Email: </b>{{$billing->email}}</li>
					<li class="font-pt font-16 mb-1"><b>City: </b>{{$billing->city}}</li>
					<li class="font-pt font-16 mb-1"><b class="text-info">Bill Pay Mathod: </b>{{$billing->billing_method}}</li>
					<li class="font-pt font-16"><b>Address: </b> {{$billing->address}}</li>
				</ul>
			</div>
		</div>


		<div class="col-12 col-lg-6 mb-3">
			<div class="card p-3">
				<h2 class="font-20 font-pt">Shipping Details</h2>
				<hr>
				<ul class="group-list">
					<li class="font-pt font-16 mb-1"><b>Name: </b>{{$shipping->first_name}} {{$shipping->last_name}}</li>
					<li class="font-pt font-16 mb-1"><b>Phone: </b>{{$shipping->phone}}</li>
					<li class="font-pt font-16 mb-1"><b>Email: </b>{{$shipping->email}}</li>
					<li class="font-pt font-16 mb-1"><b>City: </b>{{$shipping->city}}</li>
					<li class="font-pt font-16 mb-1"><b class="text-info">Shipping Cost: </b>{{$shipping->shipping_cost}} Tk</li>
					<li class="font-pt font-16"><b>Address: </b> {{$shipping->address}}</li>

				</ul>
			</div>
		</div>

		<div class="col-12  mb-3">
			<div class="card p-3">
				<h2 class="font-20 font-pt">Your Products</h2>
				<hr>

				<div class="row">

					@php
						$i = -1;
					@endphp
					@foreach($products as $product)
						@php
						  $i++;
						@endphp
						<div class="col-12 col-lg-2">
							<div class="card p-1">
								<img class="img-fluid" src="{{Storage::url($product->image)}}" alt="{{$product->name}}">
								<h5 class="font-16 font-pt my-2"><a href="/{{$product->slug}}">{{$product->name}}</a></h5>
								<h5 class="font-16 font-pt mb-2">Price: {{$product->price}} Tk</h5>
								<h5 class="font-16 font-pt">Quantity: {{$products_qty_array[$i]}} Piece</h5>
							</div>
						</div>
					@endforeach
				</div>
			</div>
		</div>


	</div>








@endsection