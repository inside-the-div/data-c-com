@extends('customer.layouts.master')



@section('title')
<title>Your All Orders</title>
@endsection


@section('content')
<!-- page title area  -->
<div class="row">
  <div class="col-12 col-lg-8">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a class="font-pt" href="/customer">Dashboard</a></li>
        </ol>
      </nav>
  </div>
</div>



 <div class="row mt-2">
   <div class="col-12">
     <div class="card p-3 rounded-0 table-responsive">

     <table class="table table-striped table-dark display " id="dataTable">
       <thead>
         <tr>
           {{-- <th scope="col">No</th> --}}
           <th scope="col">Order Id</th>
           <th scope="col">Date</th>
           <th scope="col">Process</th>
           <th scope="col">Status</th>
           <th scope="col">Payment</th>
           <th scope="col">Action</th>
         </tr>
       </thead>
      <tbody>
		@php 
			$i= 0;
		@endphp
		@foreach($orders as $order)
			@php 
				$i++;
			@endphp
         <tr>
          {{--  <td class="font-pt" >{{$i}}</td> --}}
           <td class="font-pt">{{$order->order_code}}</td>
           <td class="font-pt">{{$order->created_at->format('Y-m-d')}}</td>
           <td class="font-pt">
             <div class="progress">
               <div class="progress-bar bg-success" role="progressbar" style="width: {{$order->process}}%" aria-valuenow="{{$order->process}}" aria-valuemin="0" aria-valuemax="100"></div>
             </div>
           </td>
           <td class="font-pt">{{$order->status}}</td>
          

            <td class="font-pt">{{$order->payment}}</td>
           <td class="font-pt"><a class="cusron font-18 font-pt btn btn-info rounded-0" href="{{route('customer.order.single', ['id' => $order->id])}}">Details</a></td>
         </tr>
       @endforeach
       </tbody> 


     </table>
     </div>
   </div>
 </div>
 <!-- website info area end -->

@endsection