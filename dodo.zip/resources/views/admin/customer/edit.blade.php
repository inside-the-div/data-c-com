@extends('admin.layouts.master')



@section('title')
<title>Edit New Order</title>
@endsection


@section('content')
<!-- page title area  -->
<div class="row">
  <div class="col-12">
      <h1 class="font-josefin font-25">Edit New Order</h1>
  </div>
</div>








@endsection