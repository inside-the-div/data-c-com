@extends('admin.layouts.master')



@section('title')
<title>Add New Order</title>
@endsection


@section('content')
<!-- page title area  -->
<div class="row">
  <div class="col-12">
      <h1 class="font-josefin font-25">Add New Order</h1>
  </div>
</div>








@endsection