@extends('admin.layouts.master')

@section('title')
<title>{{Auth::user()->name}}</title>
@endsection



@section('content')


	<div class="row">
		<div class="col-12 col-lg-6">
			<div class="card p-3">
				<h1 class="font-pt font-25 text-center">Information</h1>
				<hr>

				<div class="row">
					<div class="col-12 col-lg-3">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste aut corporis ut non, distinctio consectetur voluptates veritatis. Quaerat, autem rerum.
					</div>
					<div class="col-12 col-lg-9">
						<ul>
							<li><b>Designation:</b> {{Auth::user()->designation}}</li>
							<li><b>Name:</b> {{Auth::user()->name}}</li>
							<li><b>Email:</b> {{Auth::user()->email}}</li>
							<li><b>Phone:</b> {{Auth::user()->phone}}</li>
							<li><b>Website:</b> {{Auth::user()->website}}</li>
							<li><b>Address:</b> {{Auth::user()->address}}</li>
						</ul>
					</div>
				</div>

				<div class="row mt-3">
					<div class="col-12">
						<h2 class="font-pt font-18 text-center">About</h2>
						<hr>
						<p>{{Auth::user()->about}}</p>
					</div>
				</div>
			</div>
		</div>
		<div class="col-12 col-lg-6">
			<div class="card p-3">
				<div class="row mt-3">
					<div class="col-12">
						<h1 class="font-pt font-25 text-center">Permissioins</h1>
						
						<hr>
						<p>{{Auth::user()->permissions}}</p>
					</div>
				</div>
			</div>
		</div>
	</div>

@endsection



