<p>Your Order Details</p>
<h1>Your Email is: {{$email}}</h1>
<h1>Your Password is: {{$raw_password}}</h1>
<h3>Login to check your order details</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Impedit quia porro illum nobis ad mollitia libero! Dignissimos nisi asperiores ipsum tenetur id sunt voluptates sint quam modi maxime sit, facere impedit, nam labore autem, vero eaque blanditiis illo. Minima aspernatur nesciunt rem odio, repellendus nam placeat et quibusdam earum alias!</p>