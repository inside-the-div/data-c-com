<p>email form contact from</p>

<h1>{{$name}}</h1>
<p>{{$email}}</p>
<p>{{$subject}}</p>
<p>{{$email_message}}</p>


{{-- <h1><?php  echo $data['name']; ?></h1>
<p><?php   echo $data['email']; ?></p>
<p><?php   echo $data['subject']; ?></p>
<p><?php   echo $data['email_message']; ?></p> --}}