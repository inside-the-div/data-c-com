<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductSell extends Model
{
    //

    protected $table = 'order_products';


}
