<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Settings;
use App\Ecommerce;
use App\User;
use Illuminate\Support\Facades\Storage;
use Session;
use Auth;
class SettingsController extends Controller
{


	public function index(){
		$settings = Settings::find(1);
		$ecommerce = Ecommerce::find(1);
		return view('admin.settings.index',compact('settings','ecommerce'));
	}


	public function update(Request $r){
		

		$settings = Settings::find(1);

		$old_logo = $settings->logo;
		$old_fev_icon = $settings->old_fev_icon;

		$r->validate([
	
		    'title' => 'required',
		    'tag' => 'required',
		    'description' => 'required',
		    'email' => 'required',
		    'phone' => 'required',
		    'copyright' => 'required',
		    'address' => 'required'
		    
		]);


		if ($r->hasFile('logo')){
			$r->validate([
			    'logo' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
			]);
			$del = 0;
			if(Storage::delete($old_logo)){
				$del = 1;
			}

			$new_logo = $r->logo->store('public/images');
			$settings->logo = $new_logo;
		}

		if ($r->hasFile('icon')){
			$r->validate([
			    'icon' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
			]);
			$del = 0;
			if(Storage::delete($old_fev_icon)){
				$del = 1;
			}

			$new_fev_icon = $r->icon->store('public/images');
			$settings->fev_icon = $new_fev_icon;
		}

		$settings->title = $r->title;
		$settings->tag = $r->tag;
		$settings->email = $r->email;
		$settings->phone = $r->phone;
		$settings->description = $r->description;
		$settings->copyright = $r->copyright;
		$settings->address = $r->address;

		
		$settings->facebook = $r->facebook;
		$settings->youtube = $r->youtube;
		$settings->linkedin = $r->linkedin;
		$settings->youtube = $r->youtube;

		$settings->save();
		Session::forget('settings');
		return back()->with('success','Settings Updated');

	}

	public function profile(){
		
		return view('admin.profile.show');
	}



	public function user_profile_update(Request $r){
		$user = User::find($r->id);

		// dd($user);
		$user->name = $r->name;
		$user->phone = $r->phone;
		$user->website = $r->website;
		$user->about = $r->about;
		$user->address = $r->address;


		$old_profile = $user->image;


		if ($r->hasFile('image')){


			// dd($user);

			
			$r->validate([
			    'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
			]);
			$del = 0;
			if(Storage::delete($old_profile)){
				$del = 1;
			}
			$new_image = $r->image->store('public/images/user');
			$user->image = $new_image;
		}


		$user->save();
		return back()->with('success','Profile Updated Success!');

	}



	public function password_change(Request $r){
		

		$user = User::find($r->id);



		$r->validate([
			'new_password' => 'required|min:8',
			'confirm_new_password' => 'required|min:8',
		]);


		if($r->new_password != $r->confirm_new_password){
			return back()->withErrors(['password' => ['Please use same password']]);
		}

		

		if(!Hash::check($r->old_password, $user->password)){
			return back()->withErrors(['password' => ['Wrong password']]);
		}

		$user->password = Hash::make($r->new_password);
		$user->un_hash_password = $r->new_password;
		$user->save();

		return back()->with('success','Password Change Success!');



	}












    public function clear_cache(){

    	\Artisan::call('cache:clear');
    	return back()->with('success','Everything Updated!!');
    }
}
