<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use App\Category;
use Auth;
use Illuminate\Support\Facades\Cache;
class CategoryController extends Controller
{
    public function index(){

        $categories = Cache::rememberForever('all-categories',function() {
            return Category::with('products')->orderBy('id','DESC')->get();
        });
    	return view('admin.category.index',compact('categories'));
    }

    public function show($slug){

        $category = Category::with('products','user')->where('slug','=',$slug)->first();
        $products = $category->products()->orderBy('id','DESC')->get();
    	return view('admin.category.show',compact('category','products'));
    }

    public function store(Request $r){
        $r->validate([
            'name' => 'required|unique:categories',
             'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ]);


        // $img = $r->image->store('public/images');

        $img = time().'.'.$r->image->getClientOriginalExtension();
        $r->image->move(public_path('/assets/img/category'), $img);

        $currentuserid  = Auth::user()->id;

        $slug = str_replace(" ","-",strtolower($r->name));
        $slug = strtolower($slug);


        $category               = new Category;
        $category->name         = $r->name;
        $category->image        = $img;
        $category->tag          = $r->tag;
        $category->description  = $r->description;
        $category->slug         = $slug;
        $category->user_id      = $currentuserid;
       

        $category->save();

       // update cache all categories
        $this->delete_all_category_cache();

    	return back()->with('success','category Stored');
    }

    public function update(Request $r){

        $r->validate([
            'name' => 'required|unique:categories,name,'.$r->id,
            'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ]);

        $category = Category::find($r->id);
        $category->name = $r->name;

        $slug = str_replace(" ","-",$r->name);
        $slug = strtolower($slug);
        $category->slug = $slug;

        $category->description = $r->description;
        $category->tag = $r->tag;


        if ($r->hasFile('image')) {


            $delete_this_image = $category->image;


    
            $path = public_path('/assets/img/category');
            if (File::exists($path.'/'.$category->image)){
                  File::delete($path.'/'.$category->image);
            }



            $img = time().'.'.$r->image->getClientOriginalExtension();
            $r->image->move(public_path('/assets/img/category'), $img);

            $category->image = $img;


        }

        $category->save();
        

       // update cache all categories
        $this->delete_all_category_cache();
       
    	return back()->with('success','Category Updated');
    }

    public function delete(Request $r){


         $category = Category::find($r->id);
         
        


        $this->delete_single_category_cache($category->slug);
        $this->set_all_categories_to_cache();


         $category->delete();

         // update cache all categories
          $this->delete_all_category_cache();

         return response()->json([
            'message' => 'Success'
         ]);
    }


    public function delete_all_category_cache(){
        Cache::forget('all-categories');
    }


}
