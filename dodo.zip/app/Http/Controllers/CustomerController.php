<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\Request;
use App\User;
class CustomerController extends Controller
{
   public function index(){

      $customers = Cache::rememberForever('all-custommers',function() {
          return User::with('orders')->where('type','=','customer')->get();
      });

   	return view('admin.customer.index',compact('customers'));
   }

   public function show($id){
   	return view('admin.customer.show');
   }

   public function add(){
   	return view('admin.customer.add');
   }

   public function edit($id){
   	return view('admin.customer.edit');
   }

   public function store(Request $r){
   	return back()->with('success','customer Cteaed')->route('admin.index');
   }

   public function delete(Request $r){
   	return back()->with('success','customer Deleted')->route('admin.index');
   }




   public function delete_all_customer_cache(){
       Cache::forget('all-custommers');
   }
  
}
