<?php

namespace App\Http\Controllers;


use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Auth;
use App\Order;
use App\Product;
use App\User;

use App\ShippingDetail;
use App\BillingDetail;

class OrderController extends Controller
{
    public function index(){
        $orders = Order::all();
        return view('admin.order.index',compact('orders'));
    	return view('admin.order.index');
    }

    public function show($id){


        $order = Order::find($id);
        $shipping = $order->shipping;
        $billing = $order->billing;

        $products_ids = DB::table('order_products')->where('order_id', $order->id)->get();


        $products_id_array =  [];
        $products_qty_array =  [];
        foreach ($products_ids as $p) {
            array_push($products_id_array, $p->product_id);
            array_push($products_qty_array, $p->product_quantity);
        }

        $products = Product::whereIn('id',$products_id_array)->get();
         
        return view('admin.order.show',compact('order','shipping','billing','products','products_qty_array'));
    }


    public function invoice($id){


        $order = Order::find($id);
        $customer = User::find($order->customer_id);
        $shipping = $order->shipping;
        $billing = $order->billing;

        $products_ids = DB::table('order_products')->where('order_id', $order->id)->get();


        $products_id_array =  [];
        $products_qty_array =  [];
        foreach ($products_ids as $p) {
            array_push($products_id_array, $p->product_id);
            array_push($products_qty_array, $p->product_quantity);
        }

        $products = Product::whereIn('id',$products_id_array)->get();
         
        return view('admin.order.invoice',compact('order','shipping','billing','products','products_qty_array','customer'));
    }



    public function add(){
    	return view('admin.order.add');
    }

    public function update(Request $r){
        
        $order = Order::find($r->id);

        $order->payment = $r->payment_status;
        $order->admin_note = $r->admin_note;
        $order->status = $r->order_status;
        $order->process = $r->order_processing_percentage;
        $order->payment_cost = $r->payment_cost;

        $order->save();

    	return back()->with('success','Order Update Success');
    }



    public function store(Request $r){
    	return back()->with('success','Order Stored')->route('admin.index');
    }

    public function delete(Request $r){

        $id = $r->id;
        
        Order::find($id)->delete();
        BillingDetail::where('order_id','=',$id)->delete();
        ShippingDetail::where('order_id','=',$id)->delete();
        DB::table('order_products')->where('order_id', $id)->delete();
        
    	// return back()->with('success','Order Deleted');

        return response()->json([
            'message' => 'Success'
        ]);
    }





    public function active(Request $r){
    	return back()->with('success','Order Activated');
    }
    public function deactivated(){
    	return back()->with('success','Order Deactivated');
    }
}
