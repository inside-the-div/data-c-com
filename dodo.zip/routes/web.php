<?php

use Illuminate\Support\Facades\Route;


Route::middleware(['settings'])->group(function () {
  
// get method
Route::get('/','FrontEnd\PublicController@index')->name('website.home');
Route::get('/shop','FrontEnd\EcommerceController@shop')  ->name('website.shop_page');
Route::get('/category/{slug}','FrontEnd\CategoryController@single_category')->name('website.single_category');
Route::get('/check-out', 'FrontEnd\EcommerceController@check_out')->name('website.check_out');

Route::get('/about', 'FrontEnd\PageController@about_page')->name('website.about_page');
Route::get('/condition', 'FrontEnd\PageController@condition_page')->name('website.condition_page');
Route::get('/privacy-policy', 'FrontEnd\PageController@privacy_page')->name('website.privacy_page');
Route::get('/contact', 'FrontEnd\PageController@contact_page')->name('website.contact_page');
Route::get('/faq', 'FrontEnd\PageController@faq_page')->name('website.faq_page');
Route::get('/help', 'FrontEnd\PageController@help_page')->name('website.help_page');

// post method
Route::post('/search', 'FrontEnd\PublicController@search')->name('website.search');



// get of cart 

Route::get('/cart', 'FrontEnd\CartController@view_cart')->name('website.cart.view');
Route::get('/check-out', 'FrontEnd\CartController@check_out')->name('website.cart.check_out');

});


Route::post('/add-to-cart', 'FrontEnd\CartController@add_to_cart')->name('website.cart.add');
Route::post('/delete-full-cart', 'FrontEnd\CartController@delete_full_cart')->name('website.cart.delete.full');

Route::post('/create-cart', 'FrontEnd\CartController@create_cart')->name('website.cart.create');

Route::post('/delete-cart-product', 'FrontEnd\CartController@delete_cart_product')->name('website.cart.delete.product');
Route::post('/update-cart', 'FrontEnd\CartController@update_cart')->name('website.cart.update');











// Route::post('/order/store', 'FrontEndController@store_order')->name('website.order.store');


// Route::post('/contact', 'ContactController@SendEmail')->name('website.send.email');
// Route::post('/find-me', 'CartController@find_me')->name('website.cart.findme');




// settings

// Route::middleware(['settings'])->group(function () {

  // Route::get('/', 'PublicController@home')->name('website.home');



  // Route::get('/order-submit', 'FrontEndController@order_submit')->name('website.oder.submit');
  // Route::get('/check-out', 'CartController@check_out')->name('website.check_out');
  // Route::get('/about', 'AboutController@index')->name('website.about');
  // Route::get('/condition', 'ConditionController@index')->name('website.condition');
  // Route::get('/privacy-policy', 'PrivacyController@index')->name('website.privacy');
  // Route::get('/contact', 'ContactController@index')->name('website.contact');


// });








Auth::routes();

// Route::get('/clear_cache', function () {

//     \Artisan::call('cache:clear');

//     dd("Cache is cleared");

// });


Route::group([
	'prefix' => 'admin',
	'middleware' => [
		'auth','admin','permission'
	],
], function (){

   Route::get('/', 'HomeController@index')->name('admin.home');
   Route::get('/dashboard', 'HomeController@index')->name('admin.dashboard');

   // orders 
   Route::get('/orders','OrderController@index')->name('admin.orders');
   Route::get('/order/add','OrderController@add')->name('admin.order.add');
   Route::get('/order/show/{id}','OrderController@show')->name('admin.order.show');
   Route::get('/order/invoice/{id}','OrderController@invoice')->name('admin.order.invoice');
   Route::get('/order/edit/{id}','OrderController@edit')->name('admin.order.edit');
   Route::post('/order/store','OrderController@store')->name('admin.order.store');
   Route::post('/order/update','OrderController@update')->name('admin.order.update');
   Route::post('/order/delete','OrderController@delete')->name('admin.order.delete');
   Route::post('/order/confirm','OrderController@confirm')->name('admin.order.confirm');

   // orders 
   Route::get('/customers','CustomerController@index')->name('admin.customers');
   Route::get('/customer/add','CustomerController@add')->name('admin.customer.add');
   Route::get('/customer/show/{id}','CustomerController@show')->name('admin.customer.show');
   Route::get('/customer/edit/{id}','CustomerController@edit')->name('admin.customer.edit');
   Route::post('/customer/store','CustomerController@store')->name('admin.customer.store');
   Route::post('/customer/update','CustomerController@update')->name('admin.customer.update');
   Route::post('/customer/delete','CustomerController@delete')->name('admin.customer.delete');
   Route::post('/customer/confirm','CustomerController@confirm')->name('admin.customer.confirm');

   // products 
   Route::get('/products','ProductController@index')->name('admin.products');
   Route::get('/product/add','ProductController@add')->name('admin.product.add');
   Route::get('/product/show/{slug}','ProductController@show')->name('admin.product.show');
   Route::get('/product/edit/{id}','ProductController@edit')->name('admin.product.edit');
   Route::post('/product/store','ProductController@store')->name('admin.product.store');
   Route::post('/product/update','ProductController@update')->name('admin.product.update');
   Route::post('/product/delete','ProductController@delete')->name('admin.product.delete');
   Route::post('/product/active_deactivated','ProductController@active_deactivated')->name('admin.product.active_deactivated');
   Route::post('/product/home_show_hide','ProductController@home_show_hide')->name('admin.product.home_show_hide');

   // categories
   Route::get('/categories','CategoryController@index')->name('admin.categories');
   Route::get('/category/show/{slug}','CategoryController@show')->name('admin.category.show');
   Route::post('/category/store','CategoryController@store')->name('admin.category.store');
   Route::post('/category/update','CategoryController@update')->name('admin.category.update');
   Route::post('/category/delete','CategoryController@delete')->name('admin.category.delete');



   Route::get('/emails','EmailController@index')->name('admin.emails');
   Route::get('/email/show/{id}','EmailController@show')->name('admin.email.show');
   Route::post('/email/store','EmailController@store')->name('admin.email.store');
   Route::post('/email/update','EmailController@update')->name('admin.email.update');
   Route::post('/email/delete','EmailController@delete')->name('admin.email.delete');




   // coupons
   Route::get('/coupons','CouponController@index')->name('admin.coupons');
   Route::get('/coupon/add','CouponController@add')->name('admin.coupon.add');
   Route::get('/coupon/edit/{id}','CouponController@edit')->name('admin.coupon.edit');
   Route::get('/coupon/show/{id}','CouponController@show')->name('admin.coupon.show');
   Route::post('/coupon/store','CouponController@store')->name('admin.coupon.store');
   Route::post('/coupon/update','CouponController@update')->name('admin.coupon.update');
   Route::post('/coupon/delete','CouponController@delete')->name('admin.coupon.delete');


   // packages
   Route::get('/packages','PackageController@index')->name('admin.packages');
   Route::get('/package/add','PackageController@add')->name('admin.package.add');
   Route::get('/package/show/{id}','PackageController@show')->name('admin.package.show');
   Route::get('/package/edit/{id}','PackageController@edit')->name('admin.package.edit');
   Route::post('/package/store','PackageController@store')->name('admin.package.store');
   Route::post('/package/update','PackageController@update')->name('admin.package.update');
   Route::post('/package/delete','PackageController@delete')->name('admin.package.delete');

   // reviews
   Route::get('/reviews','ReviewController@index')->name('admin.reviews');
   Route::get('/review/add','ReviewController@add')->name('admin.review.add');
   Route::get('/review/show/{id}','ReviewController@show')->name('admin.review.show');
   Route::get('/review/edit/{id}','ReviewController@edit')->name('admin.review.edit');
   Route::post('/review/store','ReviewController@store')->name('admin.review.store');
   Route::post('/review/update','ReviewController@update')->name('admin.review.update');
   Route::post('/review/delete','ReviewController@delete')->name('admin.review.delete');
   Route::post('/review/active','ReviewController@active')->name('admin.review.active');

   //seo
   Route::get('/seo','SeoController@index')->name('admin.seos');
   Route::post('/seo/home-page','SeoController@home_page')->name('admin.seo.home-page');
   Route::post('/seo/about-page','SeoController@about_page')->name('admin.seo.about-page');
   Route::post('/seo/contact-page','SeoController@contact_page')->name('admin.seo.contact-page');

   // banner
   Route::get('/banner','BannerController@index')->name('admin.banner');

   Route::post('/banner/update','BannerController@update')->name('admin.banner.update');

   // users
   Route::get('/users','CustomUserController@index')->name('admin.users');
   Route::get('/user/add','CustomUserController@add')->name('admin.user.add');
   Route::get('/user/show/{id}','CustomUserController@show')->name('admin.user.show');
   Route::get('/user/edit/{id}','CustomUserController@edit')->name('admin.user.edit');
   Route::post('/user/store','CustomUserController@store')->name('admin.user.store');
   Route::post('/user/update','CustomUserController@update')->name('admin.user.update');
   Route::post('/user/delete','CustomUserController@delete')->name('admin.user.delete');
   Route::post('/user/active','CustomUserController@active')->name('admin.user.active');

   // settings
    Route::get('/settings','SettingsController@index')->name('admin.settings');
    Route::post('/settings','SettingsController@update')->name('admin.settings.update');


    // Route::get('/ecommerce','EcommerceController@index')->name('admin.ecommerce');
    Route::get('/about','AboutController@edit')->name('admin.about');
    Route::get('/contact','ContactController@edit')->name('admin.contact');
    Route::get('/privacy','PrivacyController@edit')->name('admin.privacy');
    Route::get('/condition','ConditionController@edit')->name('admin.condition');

    Route::post('/ecommerce','EcommerceController@update')->name('admin.ecommerce.update');
    Route::post('/ecommerce/payment','EcommerceController@payment_settings')->name('admin.settings.ecommerce.payment');


    Route::post('/about','AboutController@update')->name('admin.about.update');
    Route::post('/contact','ContactController@update')->name('admin.contact.update');
    Route::post('/privacy','PrivacyController@update')->name('admin.privacy.update');
    Route::post('/condition','ConditionController@update')->name('admin.condition.update');


    // profile 
    Route::get('/profile', 'SettingsController@profile')->name('admin.profile');
    Route::post('/profile', 'SettingsController@user_profile_update')->name('admin.profile.update');
    Route::post('/profile/password', 'SettingsController@password_change')->name('admin.profile.password_change');


    // data 
    Route::get('/data','DataController@index')->name('admin.data');
    Route::get('/data/sells','DataController@sells')->name('admin.data.sells');
    Route::post('/data/sells','DataController@sells_download')->name('admin.data.sells.download');

    Route::get('/data/products','DataController@products')->name('admin.data.products');
    Route::post('/data/products','DataController@products_download')->name('admin.data.products.download');

    Route::get('/data/orders','DataController@orders')->name('admin.data.orders');
    Route::post('/data/orders','DataController@orders_download')->name('admin.data.orders.download');



    // slider
    Route::get('/sliders','SliderController@index')->name('admin.sliders');
    Route::get('/slider/add','SliderController@add')->name('admin.slider.add');
    Route::get('/slider/edit/{id}','SliderController@edit')->name('admin.slider.edit');
    Route::get('/slider/show/{id}','SliderController@show')->name('admin.slider.show');
    Route::post('/slider/store','SliderController@store')->name('admin.slider.store');
    Route::post('/slider/active','SliderController@active')->name('admin.slider.active');
    Route::post('/slider/delete','SliderController@delete')->name('admin.slider.delete');


    // faq
    Route::get('/faqs','FaqController@index')->name('admin.faqs');
    Route::get('/faq/add','FaqController@add')->name('admin.faq.add');
    Route::get('/faq/edit/{id}','FaqController@edit')->name('admin.faq.edit');
    Route::get('/faq/show/{id}','FaqController@show')->name('admin.faq.show');
    Route::post('/faq/store','FaqController@store')->name('admin.faq.store');
    Route::post('/faq/update','FaqController@update')->name('admin.faq.update');
    Route::post('/faq/delete','FaqController@delete')->name('admin.faq.delete');


    // cache 


     
    
});



// cache gorute

Route::post('/clear-cache', 'CacheControl@clear_cache')->name('admin.cache.clear');





Route::group([
   'prefix' => 'customer',
   'middleware' => [
      'auth','customer',
   ],
], function (){

   Route::get('/', 'CustomerDashboardController@index')->name('customer.home');
   Route::get('/order', 'CustomerDashboardController@order')->name('customer.order');
   Route::get('/order/{id}', 'CustomerDashboardController@single')->name('customer.order.single');
   Route::get('/profile', 'CustomerDashboardController@profile')->name('customer.profile');
   Route::post('/profile', 'CustomerDashboardController@user_profile_update')->name('customer.profile.update');
   Route::post('/profile/passowrd', 'CustomerDashboardController@password_change')->name('customer.profile.password_change');
  
});







Route::middleware(['settings'])->group(function () {
  Route::get('/{slug}', 'FrontEnd\ProductController@single_product')->name('website.single_product');
});