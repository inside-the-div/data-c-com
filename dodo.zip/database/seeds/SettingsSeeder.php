<?php

use Illuminate\Database\Seeder;
use App\Settings;
class SettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	$settings = new Settings;
        $settings->title = "title";
        $settings->fev_icon = "icon";
        $settings->logo = "logo";
        $settings->tag = "tag";
        $settings->email = "Test@gmail.com" ;
        $settings->phone = "+880 1XXXXXXXX";
        $settings->description = "description";
        $settings->copyright = "copyright";
        $settings->address = "address";

        
        $settings->facebook = "facebook";
        $settings->youtube = "youtube";
        $settings->linkedin = "linkedin";
        $settings->youtube = "youtube";

        $settings->save();
    }
}
